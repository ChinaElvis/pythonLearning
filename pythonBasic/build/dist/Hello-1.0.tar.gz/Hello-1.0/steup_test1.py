from distutils.core import setup
setup(name='Hello',
      version='1.0',
      description='A simple example',
      author='elvis',
      py_modules=['hello'])

